// 多言語対応機能
class LanguageManager {
  constructor() {
    this.currentLanguage = localStorage.getItem('language') || 'ja';
    this.translations = window.i18nData || {};
  }

  // 言語を設定
  setLanguage(lang) {
    if (this.translations[lang]) {
      this.currentLanguage = lang;
      localStorage.setItem('language', lang);
      this.updatePage();
      this.updateLanguageButtons();
    }
  }

  // 現在の言語を取得
  getCurrentLanguage() {
    return this.currentLanguage;
  }

  // 翻訳テキストを取得
  translate(key) {
    const translation = this.translations[this.currentLanguage];
    return translation && translation[key] ? translation[key] : key;
  }

  // ページ全体を更新
  updatePage() {
    // data-i18n属性を持つ要素を更新
    document.querySelectorAll('[data-i18n]').forEach(element => {
      const key = element.getAttribute('data-i18n');
      const translation = this.translate(key);
      
      // 要素の内容を更新（子要素がない場合）
      if (element.children.length === 0) {
        element.textContent = translation;
      } else {
        // 子要素がある場合は、最初のテキストノードを探して更新
        for (let i = 0; i < element.childNodes.length; i++) {
          const node = element.childNodes[i];
          if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
            node.textContent = translation;
            break;
          }
        }
      }
    });

    // placeholder属性も更新
    document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
      const key = element.getAttribute('data-i18n-placeholder');
      element.placeholder = this.translate(key);
    });
    
    // titleも更新
    const titleElement = document.querySelector('title[data-i18n]');
    if (titleElement) {
      const key = titleElement.getAttribute('data-i18n');
      document.title = this.translate(key);
    }
  }

  // 言語切り替えボタンの状態を更新
  updateLanguageButtons() {
    document.querySelectorAll('.lang-btn').forEach(btn => {
      const lang = btn.getAttribute('data-lang');
      if (lang === this.currentLanguage) {
        btn.classList.add('active');
        btn.classList.remove('inactive');
      } else {
        btn.classList.remove('active');
        btn.classList.add('inactive');
      }
    });
  }

  // 言語切り替えボタンを初期化
  initLanguageButtons() {
    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const lang = btn.getAttribute('data-lang');
        this.setLanguage(lang);
      });
    });
    this.updateLanguageButtons();
  }
}

// グローバルインスタンスを作成
window.languageManager = new LanguageManager();

// グローバル翻訳関数（JavaScript内で使用）
window.i18n = function(key) {
  return window.languageManager.translate(key);
};

// ページ読み込み時に実行
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.languageManager.updatePage();
    window.languageManager.initLanguageButtons();
  });
} else {
  // DOMが既に読み込まれている場合は即座に実行
  window.languageManager.updatePage();
  window.languageManager.initLanguageButtons();
}
