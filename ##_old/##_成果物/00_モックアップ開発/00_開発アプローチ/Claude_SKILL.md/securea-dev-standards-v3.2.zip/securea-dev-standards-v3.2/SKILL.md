---
name: securea-dev-standards
description: Development standards for SECUREA City project. Defines file naming conventions, global variable management, CSS naming (BEM), 3-layer screen structure, and common rules. Unified rules applied when creating/editing HTML, CSS, and JavaScript files.
---

# SECUREA City Development Standards

## Overview
Development standards for SECUREA City project. Unified rules that must be applied when creating/editing HTML, CSS, and JavaScript files.

## When to Use
- Creating/editing HTML files
- Creating/editing CSS files
- Creating/editing JavaScript files
- Creating new screens
- Modifying existing code

---

## CRITICAL: Code Generation Procedure

### Basic Principles
1. **Reference existing files first** (highest priority)
2. Follow this skill's rules
3. Verify with checklist

### Importance of Referencing Existing Files
Always reference existing similar files when creating new ones. Maintain consistency by following existing file patterns.

---

## Detailed Documentation

This skill includes the following detailed documents.
Reference as needed:

### Code Generation (⭐ Read This First)
- **See Project Knowledge: code-generation-rules_v2.md** - Critical rules for code generation (CSS variables, translation keys, CSS placement, translation file organization)

### Basic Rules
- **naming-conventions.md** - File names, variable names, CSS class naming rules
- **directory-structure.md** - Project directory structure
- **common-rules.md** - Common rules (buttons, global variables)
- **file-headers.md** - File header comment conventions
- **document-versioning.md** - Document version management rules

### Screen Creation
- **page-structure.md** - 3-layer screen structure (header, content, footer)
- **new-page-guide.md** - New screen creation procedure
- **templates/page-template.html** - Screen template

### Troubleshooting
- **troubleshooting.md** - Top 3 issues and prevention
- **checklist.md** - Checklist and prohibited items

---

## Quick Reference

### Naming Basics
```
File names: kebab-case (home.html, language-switcher.js)
Global variables: window.Capitalized (window.LanguageSwitcher)
CSS classes: BEM notation (.footer-nav__button--active)
JS functions: camelCase (initLanguageSwitcher)
```

### Must Follow
- ❌ No `!important` usage
- ❌ No underscore-separated file names
- ❌ No custom edits to header/footer areas
- ✅ Strict CSS load order (Tailwind CDN → variables → reset → base → common → pages)
- ✅ Use Tailwind CDN (all screens)
- ✅ Place logout button at footer right edge
- ✅ Reference existing files

---

## Translation File Structure

### Screen-based Organization (⭐ IMPORTANT)

**Each screen has its own translation files:**

```
pages/home/
├── home.html
├── home.css
├── home.js
├── home.ja.js      ← Japanese translations
├── home.en.js      ← English translations
└── home.zh.js      ← Chinese translations

js/i18n/langs/
├── common.ja.js    ← Common only (header, footer, buttons)
├── common.en.js
└── common.zh.js
```

**Why?**
- Scalability: Avoids 1,440+ line files (violates 300-line rule)
- Independence: Each screen is self-contained
- Performance: Load only needed translations

**For detailed rules and examples, see Project Knowledge:**
- `code-generation-rules_v2.md` - Rule 4: Translation File Organization

---

## Reference: Existing Project Documents

For more details, refer to:
- **code-generation-rules_v2.md** (Project Knowledge) - Critical code generation rules
- **04_開発ガイドライン_コーディング規約とデザイン原則_v02.md** - 3-click rule, file header conventions
- **01_機能要件定義書.pdf** - Screen specs, functional requirements
- **03_マルチテナント設計仕様書.md** - Database design

---

## Notes

**This skill's rules are updated as issues are found during development.**

If you have questions or concerns, reference existing code or explicitly ask for clarification.

---

## Change Log
- 2025/10/25 v3.2: Replaced code-generation-rules.md with Project Knowledge reference; Added translation file structure overview
- 2025/10/25 v3.1: Added code-generation-rules.md (CSS variables, translation keys, CSS placement)
- 2025/10/24 v3.0: Full English translation for better efficiency
- 2025/10/24 v2.3: Clarified screen-specific file naming rules (added feature-based splitting rules)
- 2025/10/24 v2.2: Added document version management rules
- 2025/10/24 v2.1: Added Tailwind CDN usage rules, logout button placement rules
