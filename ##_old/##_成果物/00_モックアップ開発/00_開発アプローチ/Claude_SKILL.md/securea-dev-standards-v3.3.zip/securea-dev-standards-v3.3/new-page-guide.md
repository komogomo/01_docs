# New Page Creation Guide

## Step-by-Step Procedure

---

## Step 1: Create Directory

```bash
mkdir pages/[screen-name]/
```

Example:
```bash
mkdir pages/home/
```

---

## Step 2: Copy Template

```bash
cp templates/page-template.html pages/[screen-name]/[screen-name].html
```

Example:
```bash
cp templates/page-template.html pages/home/home.html
```

---

## Step 3: Create CSS/JS Files

```bash
touch pages/[screen-name]/[screen-name].css
touch pages/[screen-name]/[screen-name].js
```

Example:
```bash
touch pages/home/home.css
touch pages/home/home.js
```

---

## Step 4: Edit HTML File

### 4.1 Update File Header
```html
<!--
  File: /pages/home/home.html
  Screen: Home Screen
-->
```

### 4.2 Fix CSS Load Path
```html
<!-- Screen-specific CSS (same directory) -->
<link rel="stylesheet" href="home.css">
```

### 4.3 Fix JS Load Path
```html
<!-- Screen-specific JavaScript (same directory) -->
<script src="home.js"></script>
```

### 4.4 Edit Content Area
Modify only `<main>` section

---

## Step 5: Create Translation Files

### Create Screen-specific Translation Files

Create 3 translation files in the **same directory as HTML**:

```bash
# Example: pages/home/ directory
touch pages/home/home.ja.js
touch pages/home/home.en.js
touch pages/home/home.zh.js
```

### Add Screen Content Keys

```javascript
// home.ja.js
window.I18nData = window.I18nData || { translations: {} };
window.I18nData.translations.ja = window.I18nData.translations.ja || {};

Object.assign(window.I18nData.translations.ja, {
  'home.title': 'ホーム',
  'home.welcome': 'ようこそ',
  // ... other home-specific keys
});

// home.en.js
window.I18nData = window.I18nData || { translations: {} };
window.I18nData.translations.en = window.I18nData.translations.en || {};

Object.assign(window.I18nData.translations.en, {
  'home.title': 'Home',
  'home.welcome': 'Welcome',
  // ... other home-specific keys
});

// home.zh.js
window.I18nData = window.I18nData || { translations: {} };
window.I18nData.translations.zh = window.I18nData.translations.zh || {};

Object.assign(window.I18nData.translations.zh, {
  'home.title': '主页',
  'home.welcome': '欢迎',
  // ... other home-specific keys
});
```

### Load Order in HTML

```html
<body>
  <!-- 1. Common translations (header, footer) -->
  <script src="../../js/i18n/langs/common.ja.js"></script>
  <script src="../../js/i18n/langs/common.en.js"></script>
  <script src="../../js/i18n/langs/common.zh.js"></script>
  
  <!-- 2. Common features -->
  <script src="../../js/features/language-switcher.js"></script>
  <script src="../../js/features/translator.js"></script>
  <script src="../../js/features/footer-navigation.js"></script>
  
  <!-- 3. Screen-specific translations (content area) -->
  <script src="home.ja.js"></script>
  <script src="home.en.js"></script>
  <script src="home.zh.js"></script>
  
  <!-- 4. Screen-specific logic -->
  <script src="home.js"></script>
</body>
```

**Important:**
- Common keys (header, footer, buttons) → `js/i18n/langs/common.[lang].js`
- Screen content keys → `pages/[screen]/[screen].[lang].js`
- Always add to ALL 3 language files (ja, en, zh)

---

## Step 6: Test Locally

### Check List
- □ Load screen in browser
- □ Switch languages (JA/EN/ZH)
- □ Check translations work
- □ Check styles applied
- □ Check footer nav active state
- □ Check console for errors

---

## Quick Checklist

New screen creation checklist:

- □ Created `pages/[screen]/` directory
- □ Copied template
- □ Added file header comment
- □ Created CSS/JS in **same directory**
- □ Fixed CSS/JS load paths (same directory)
- □ Added Tailwind CDN
- □ Added logout button (footer right)
- □ Created screen translation files ([screen].ja.js, [screen].en.js, [screen].zh.js)
- □ Loaded translations in correct order (common → screen-specific)
- □ Tested locally
- □ Language switching works
- □ Footer nav works
- □ Logout button works

---

## Common Mistakes

### 1. CSS/JS in Wrong Location
❌ css/pages/home.css
✓ pages/home/home.css

### 2. Wrong Load Path
❌ `<link href="../../css/pages/home.css">`
✓ `<link href="home.css">`

### 3. Translation Files in Wrong Location
❌ js/i18n/langs/ja.js (all screens mixed)
✓ pages/home/home.ja.js (screen-specific)
✓ js/i18n/langs/common.ja.js (common only)

### 4. Missing Translation in Any Language
Must add to ALL three language files (ja/en/zh)

### 5. Editing Header/Footer
Only edit `<main>` content area
