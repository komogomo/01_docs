# Document Version Management

## Version Control Rules

### File Name vs Content Version

**IMPORTANT:** Version management differs by file type

---

## Code Files (HTML/CSS/JS)

### Rule
**DO NOT include version in filename**

❌ Wrong:
```
header-v2.css
template-fixed.html
main-2.0.js
```

✓ Correct:
```
header.css
template.html
main.js
```

### Version Management
- Use **Git commit messages** for version history
- Use **file header comments** for change notes
- Keep original filename when modifying

### Example
```css
/**
 * File: /css/common/header.css
 * Purpose: Common header styles
 * 
 * Last Modified: 2025/10/24
 * Changes: Added language switcher layout
 */
```

---

## Documentation Files (MD/PDF)

### Rule
**Include version in content, optionally in filename**

✓ Acceptable:
```
requirements-v2.0.md
design-specs.md (version in content)
```

### In-Document Version
```markdown
# Project Requirements

**Version:** 2.0
**Date:** 2025/10/24
**Changes:** Added multilingual support
```

---

## When Modifying Existing Files

### DO
✅ Keep original filename
✅ Update header comment
✅ Write clear commit message
✅ Document changes in content

### DON'T
❌ Create header-fixed.css
❌ Create header_new.css
❌ Create header-v2.css
❌ Keep old versions uncommitted

---

## File Output Classification

When delivering files to users, clearly indicate:

### New Files
- **Label:** [NEW] template.html
- **Action:** Add to project

### Modified Files
- **Label:** [MODIFIED] header.css
- **Action:** Replace existing file

### Reference Files
- **Label:** [REFERENCE] example.css
- **Action:** For reference only, don't add to project
