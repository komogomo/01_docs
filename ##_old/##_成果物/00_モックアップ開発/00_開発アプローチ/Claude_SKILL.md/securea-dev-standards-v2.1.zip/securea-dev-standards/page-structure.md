# 画面の3層構造

## 基本構造

index.html以外のすべての画面は以下の3層構造を持つ：

1. **ヘッダー領域**（共通・編集不要）
2. **コンテンツ領域**（画面固有・ここだけ編集）
3. **フッター領域**（共通・編集不要）

---

## 標準HTMLテンプレート

```html
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>[画面名] - セキュレアシティ</title>
  
  <!-- Tailwind CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  
  <!-- CSS読み込み（順序厳守） -->
  <link rel="stylesheet" href="../../css/variables.css">
  <link rel="stylesheet" href="../../css/reset.css">
  <link rel="stylesheet" href="../../css/base.css">
  <link rel="stylesheet" href="../../css/common/button.css">
  <link rel="stylesheet" href="../../css/common/header.css">
  <link rel="stylesheet" href="../../css/common/footer.css">
  <link rel="stylesheet" href="../../css/common/layout.css">
  
  <!-- 画面固有CSS（同じディレクトリ） -->
  <link rel="stylesheet" href="[画面].css">
  
  <!-- 翻訳データ -->
  <script src="../../js/i18n/langs/ja.js"></script>
  <script src="../../js/i18n/langs/en.js"></script>
  <script src="../../js/i18n/langs/zh.js"></script>
  
  <!-- 独立機能 -->
  <script src="../../js/features/language-switcher.js"></script>
  <script src="../../js/features/translator.js"></script>
  <script src="../../js/features/footer-navigation.js"></script>
</head>
<body>
  <!-- ========================================
       ヘッダー領域（共通・編集不要）
       ======================================== -->
  <header class="page-header">
    <div class="header-top">
      <div class="header-logo">
        <span data-i18n="common.app.name">セキュレアシティ</span>
      </div>
      <div class="header-actions">
        <button class="notification-btn" aria-label="通知">
          <span class="notification-icon">🔔</span>
        </button>
        <div class="language-switcher">
          <button class="lang-btn" data-lang="ja">JA</button>
          <button class="lang-btn" data-lang="en">EN</button>
          <button class="lang-btn" data-lang="zh">ZH</button>
        </div>
      </div>
    </div>
    <h1 class="header-title" data-i18n="[画面ID].header.title">
      [画面タイトル]
    </h1>
  </header>

  <!-- ========================================
       コンテンツ領域（画面固有・ここだけ編集）
       ======================================== -->
  <main class="page-content">
    <div class="content-container">
      <!-- ここに画面固有の内容 -->
    </div>
  </main>

  <!-- ========================================
       フッター領域（共通・編集不要）
       ======================================== -->
  <footer class="page-footer">
    <a href="../home/home.html" class="footer-nav-btn" data-page="home">
      <span class="footer-nav-icon">🏠</span>
      <span class="footer-nav-label" data-i18n="footer.nav.home">ホーム</span>
    </a>
    <a href="../notice/notice.html" class="footer-nav-btn" data-page="notice">
      <span class="footer-nav-icon">📢</span>
      <span class="footer-nav-label" data-i18n="footer.nav.notice">お知らせ</span>
    </a>
    <a href="../board/board.html" class="footer-nav-btn" data-page="board">
      <span class="footer-nav-icon">📋</span>
      <span class="footer-nav-label" data-i18n="footer.nav.board">掲示板</span>
    </a>
    <a href="../booking/booking.html" class="footer-nav-btn" data-page="booking">
      <span class="footer-nav-icon">🅿️</span>
      <span class="footer-nav-label" data-i18n="footer.nav.booking">駐車場</span>
    </a>
    <a href="../mypage/mypage.html" class="footer-nav-btn" data-page="mypage">
      <span class="footer-nav-icon">👤</span>
      <span class="footer-nav-label" data-i18n="footer.nav.mypage">マイページ</span>
    </a>
    <button class="footer-nav-btn logout-btn" data-action="logout">
      <span class="footer-nav-icon">🚪</span>
      <span class="footer-nav-label" data-i18n="footer.nav.logout">ログアウト</span>
    </button>
  </footer>

  <!-- 画面固有JavaScript（同じディレクトリ） -->
  <script src="[画面].js"></script>
</body>
</html>
```

---

## 各層の役割

### 1. ヘッダー領域（共通）
- アプリ名（ロゴ）
- 通知ボタン
- 言語切替ボタン
- 画面タイトル
- **編集禁止**：すべての画面で共通の構造を維持

### 2. コンテンツ領域（画面固有）
- `<main class="page-content">` 内のみを編集
- 画面固有の機能・表示内容を実装
- **ここだけを編集**すること

### 3. フッター領域（共通）
- フッターナビゲーション（5つのボタン）
- ログアウトボタン（右端）
- **編集禁止**：すべての画面で共通の構造を維持

---

## CSS読み込み順序（厳守）

```
1. Tailwind CDN       # ユーティリティCSS
2. variables.css      # CSS変数定義
3. reset.css          # リセットCSS
4. base.css           # 基本スタイル
5. common/button.css  # 共通ボタン
6. common/header.css  # ヘッダー
7. common/footer.css  # フッター
8. common/layout.css  # レイアウト
9. [画面].css         # 画面固有スタイル（同じディレクトリ）
```

**この順序を変更すると、スタイルが正しく適用されない可能性があります。**

---

## JavaScript読み込み順序（厳守）

```
1. 翻訳データ（ja.js, en.js, zh.js）
2. 独立機能（language-switcher.js, translator.js, footer-navigation.js）
3. 画面固有JavaScript（[画面].js - 同じディレクトリ）
```

**翻訳データを先に読み込まないと、言語切替が機能しません。**
