# トラブルシューティング

よくある問題とその防止策をまとめています。

---

## 1. スタイルシートが適用されない

### 原因
- CSS読み込み順序の誤り
- CSS specificity の衝突
- クラス名のtypo

### 防止策
1. **CSS読み込み順序を厳守**
   ```
   variables → reset → base → common → pages
   ```
   
2. **`!important` は使用禁止**
   - specificity の問題を引き起こす
   - メンテナンスが困難になる
   
3. **BEM記法を正しく使用**
   - クラス名の衝突を回避
   - specificity を適切に保つ

### デバッグ方法
```
1. ブラウザ開発者ツールでCSSが読み込まれているか確認
2. 適用されているスタイルの優先順位を確認
3. クラス名が正しいか確認
```

---

## 2. 言語切替が機能しない

### 原因
- 独立機能の読み込み順序の誤り
- グローバル変数の未定義
- JavaScriptエラーの発生

### 防止策
1. **翻訳データを先に読み込む**
   ```html
   <!-- 翻訳データ -->
   <script src="../../js/i18n/langs/ja.js"></script>
   <script src="../../js/i18n/langs/en.js"></script>
   <script src="../../js/i18n/langs/zh.js"></script>
   
   <!-- その後に独立機能 -->
   <script src="../../js/features/language-switcher.js"></script>
   <script src="../../js/features/translator.js"></script>
   ```

2. **読み込み順序を守る**
   ```
   language-switcher.js → translator.js → footer-navigation.js
   ```

3. **グローバル変数を確認**
   ```javascript
   // ブラウザコンソールで確認
   console.log(window.LanguageSwitcher);
   console.log(window.Translator);
   console.log(window.I18nData);
   ```

### デバッグ方法
```
1. ブラウザコンソールでエラーメッセージを確認
2. window.I18nData が正しく定義されているか確認
3. 言語切替ボタンのクリックイベントが動作しているか確認
```

---

## 3. 翻訳されない

### 原因
- data-i18n 属性の誤り
- 翻訳データの不足
- 翻訳キーの不一致

### 防止策
1. **data-i18n 属性を正しく設定**
   ```html
   <!-- 正しい -->
   <h1 data-i18n="home.title">ホーム</h1>
   
   <!-- 間違い -->
   <h1 data-i18n="homeTitle">ホーム</h1>
   ```

2. **翻訳キーの形式を統一**
   ```
   [画面ID].[セクション].[要素]
   
   例:
   home.header.title
   home.news.title
   board.post.button
   ```

3. **すべての言語ファイルに同じキーを定義**
   ```javascript
   // ja.js
   'home.title': 'ホーム',
   
   // en.js
   'home.title': 'Home',
   
   // zh.js
   'home.title': '主页',
   ```

### デバッグ方法
```
1. ブラウザコンソールで window.I18nData.translations を確認
2. 該当する翻訳キーが存在するか確認
3. data-i18n 属性の値が正しいか確認
```

---

## 4. フッターナビのアクティブ状態が正しくない

### 原因
- data-page 属性の誤り
- footer-navigation.js が読み込まれていない
- 現在のページ判定ロジックの問題

### 防止策
1. **data-page 属性を正しく設定**
   ```html
   <!-- home.html の場合 -->
   <a href="../home/home.html" class="footer-nav-btn" data-page="home">
   ```

2. **footer-navigation.js を確実に読み込む**
   ```html
   <script src="../../js/features/footer-navigation.js"></script>
   ```

### デバッグ方法
```
1. ブラウザコンソールで現在のページ名を確認
2. data-page 属性の値を確認
3. .footer-nav-btn--active クラスが適用されているか確認
```

---

## 5. ローカルサーバーで動作しない

### 原因
- ファイルプロトコル（file://）での実行
- CORSポリシー違反
- 相対パスの誤り

### 解決策
1. **必ずローカルサーバーを使用**
   ```bash
   npx http-server
   ```

2. **file:// プロトコルでは実行しない**
   - JavaScriptの一部機能が制限される
   - モジュールが読み込めない

---

## トラブルシューティングの基本手順

### 1. ブラウザコンソールを確認
```
F12キー → Console タブ
エラーメッセージを確認
```

### 2. ネットワークタブを確認
```
F12キー → Network タブ
ファイルが正しく読み込まれているか確認
404エラーがないか確認
```

### 3. 要素検証ツールを使用
```
F12キー → Elements タブ
適用されているCSSを確認
data-i18n 属性を確認
```

### 4. 段階的にデバッグ
```
1. HTMLの構造を確認
2. CSSの読み込みを確認
3. JavaScriptのエラーを確認
4. 一つずつ問題を切り分ける
```
