# 新規画面作成の手順

新規画面を作成する際の標準的な手順を説明します。

---

## ステップ1: 既存画面を参照

既存の類似画面を開いて構造を確認すること。
特に `home` ディレクトリは基本的な構造を含んでいるため、参考にすると良い。

```
参照推奨ファイル:
- pages/home/home.html（基本構造）
- pages/home/home.css（スタイル記述例）
- pages/home/home.js（JavaScript記述例）
```

---

## ステップ2: テンプレートを使用

### オプションA: テンプレートファイルを使用
```
templates/page-template.html をコピーして使用
```

### オプションB: 既存画面をコピー
```
pages/home/ ディレクトリをコピーして修正
```

**推奨：** オプションAのテンプレートファイルを使用すると、最新の構造が反映される。

---

## ステップ3: ファイル作成

### 3-1. ディレクトリ作成
```bash
mkdir pages/[画面名]/
```

### 3-2. HTMLファイル
```
作成場所: pages/[画面名]/[画面名].html
例: pages/board/board.html
```

### 3-3. CSSファイル
```
作成場所: pages/[画面名]/[画面名].css（HTMLと同じディレクトリ）
例: pages/board/board.css
```

### 3-4. JavaScriptファイル（必要な場合）
```
作成場所: pages/[画面名]/[画面名].js（HTMLと同じディレクトリ）
例: pages/board/board.js
```

**重要:** HTML/CSS/JSは**同一ディレクトリ**に配置

---

## ステップ4: HTMLファイルの編集

### 4-1. プレースホルダーの置換

テンプレート内の以下を置換：

```
[画面ID] → 実際の画面ID（例: board, parking, survey）
[画面名] → ファイル名（例: board, parking, survey）
```

**置換対象：**
- ページタイトル（`<title>`）
- CSS読み込みパス（`href="[画面].css"`） ← 同じディレクトリ
- JavaScript読み込みパス（`src="[画面].js"`） ← 同じディレクトリ
- data-i18n属性（`data-i18n="[画面ID].header.title"`）

### 4-2. コンテンツ領域のみ編集

```html
<main class="page-content">
  <div class="content-container">
    <!-- ここに画面固有の内容を記述 -->
  </div>
</main>
```

**重要：**
- ヘッダー領域は編集不要
- フッター領域は編集不要
- コンテンツ領域（`<main>`）のみを編集

---

## ステップ5: CSSファイルの作成

### 5-1. ファイルヘッダーを記載

```css
/**
 * 設置パス: /pages/board/board.css
 * ファイル名: 掲示板画面固有スタイル
 * 
 * 対象:
 * - .board-list（投稿一覧）
 * - .board-post（投稿フォーム）
 */
```

### 5-2. BEM記法でスタイルを定義

```css
/* Block */
.board-list { }

/* Element */
.board-list__item { }

/* Modifier */
.board-list__item--unread { }
```

---

## ステップ6: 翻訳データの追加

### 6-1. すべての言語ファイルに追加

```javascript
// js/i18n/langs/ja.js
window.I18nData.translations.ja = {
  ...window.I18nData.translations.ja,
  'board.header.title': '掲示板',
  'board.post.button': '投稿する',
  'board.list.title': '投稿一覧',
};

// js/i18n/langs/en.js
window.I18nData.translations.en = {
  ...window.I18nData.translations.en,
  'board.header.title': 'Board',
  'board.post.button': 'Post',
  'board.list.title': 'Post List',
};

// js/i18n/langs/zh.js
window.I18nData.translations.zh = {
  ...window.I18nData.translations.zh,
  'board.header.title': '留言板',
  'board.post.button': '发布',
  'board.list.title': '帖子列表',
};
```

### 6-2. 翻訳キーの命名規則

```
[画面ID].[セクション].[要素]

例:
board.header.title
board.post.button
board.list.item.author
```

---

## ステップ7: JavaScriptファイルの作成（必要な場合）

### 7-1. ファイルヘッダーを記載

```javascript
/**
 * 設置パス: /pages/board/board.js
 * 機能名: 掲示板画面固有処理
 * 
 * 依存関係:
 * - なし
 * 
 * 概要:
 * 投稿フォームの制御と投稿一覧の表示。
 */
```

### 7-2. 即時関数でスコープを分離

```javascript
(function() {
  'use strict';
  
  // ページ固有の変数・関数
  let posts = [];
  
  function initBoardPage() {
    // 初期化処理
  }
  
  // ページ読み込み時に実行
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initBoardPage);
  } else {
    initBoardPage();
  }
})();
```

---

## ステップ8: 動作確認

### 8-1. ローカルサーバーで起動

```bash
npx http-server
```

### 8-2. ブラウザで確認

```
http://localhost:8080/pages/[画面名]/[画面名].html
```

### 8-3. 確認項目

- □ ページが正しく表示されるか
- □ スタイルが適用されているか
- □ 言語切替が動作するか
- □ すべての言語で翻訳が表示されるか
- □ フッターナビのアクティブ状態は正しいか
- □ ブラウザコンソールにエラーがないか

---

## ステップ9: チェックリストで最終確認

`checklist.md` のチェックリストで全項目を確認すること。

特に以下を重点的に確認：
- 命名規則が守られているか
- ファイル配置が正しいか（同一ディレクトリ）
- 翻訳データが全言語に存在するか
- 禁止事項に違反していないか

---

## トラブルシューティング

問題が発生した場合は `troubleshooting.md` を参照すること。

よくある問題：
- スタイルが適用されない → CSS読み込みパスを確認（同じディレクトリから読み込んでいるか）
- 言語切替が動作しない → JavaScript読み込み順序を確認
- 翻訳されない → data-i18n属性と翻訳キーを確認

---

## ベストプラクティス

### 段階的に作成
1. まずHTMLの構造のみ作成
2. 次にCSSでスタイリング
3. 最後にJavaScriptで動的機能を追加

### こまめに確認
- 1つのセクションを作成したら動作確認
- 問題が発生したらすぐに対処
- 最後にまとめて確認しない

### 既存パターンを踏襲
- 新しい方法を試す前に既存コードを確認
- 統一性を保つことを優先
- 必要があれば全体的にリファクタリング

---

## ディレクトリ構造例

```
pages/board/
├── board.html          ← HTML
├── board.css           ← CSS（同じディレクトリ）
└── board.js            ← JS（同じディレクトリ）
```

**旧構造との違い:**
```
旧: pages/board/board.html, css/pages/board.css, js/pages/board.js
新: pages/board/ の中に全て配置
```
