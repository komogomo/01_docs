# Code Generation Rules

## Overview
Critical rules that must be followed when generating code. These rules prevent common errors discovered during actual development.

---

## Rule 1: Required CSS Variables

### Must Define Before Use

**MUST define these variables in `variables.css` before using them in any CSS file:**

```css
/* Layout */
--footer-height: 70px;
--max-width-content: 1024px;

/* Spacing */
--spacing-2: 0.5rem;
--spacing-4: 1rem;
--spacing-6: 1.5rem;
--spacing-8: 2rem;

/* Colors */
--text-primary: #111827;
--bg-card: #ffffff;

/* Typography */
--font-size-xl: 1.25rem;

/* Border */
--radius-lg: 0.5rem;

/* Shadow */
--shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);

/* Z-index */
--z-header: 50;
--z-footer: 100;
```

### Why This Matters

Layout calculations in `layout.css` depend on these variables. Missing variables cause **silent failures** - the page may render without errors, but spacing and layout will be incorrect.

### Pre-Generation Checklist

Before generating any CSS code:

- [✓] All required variables exist in `variables.css`
- [✓] No hardcoded values that should be variables
- [✓] All `var()` references have corresponding definitions
- [✓] `layout.css` calculations will work correctly

---

## Rule 2: Translation Keys - 3 Language Set Required

### The 3-Language Rule

**CRITICAL: When adding ANY translation key, add to ALL 3 files simultaneously:**

1. `ja.js` (Japanese) [✓]
2. `en.js` (English) [✓]
3. `zh.js` (Chinese) [✓]

Missing keys in any language file causes **raw key display** instead of translated text.

### Example: Complete Implementation

```javascript
// ja.js
home: {
notice: {
new: '',

all: 'ž¹¦'
},
welcome: {
title: '  '

}
}

// en.js
home: {
notice: {
new: 'New',
all: 'All'
},
welcome: {
title: 'Welcome'
}
}

// zh.js
home: {
notice: {
new: '"',

all: ''

},
welcome: {
title: ''

}
}
```

### What Happens If You Forget

**Bad Example** (missing key in en.js):
```
User switches to English  sees "home.notice.new" instead of "New"

```

### Verification Process

**Step 1: Extract all keys from HTML**
```bash
grep -o 'data-i18n="[^"]*"' home.html
```

**Step 2: Verify in all 3 files**
- Check `ja.js` has the key
- Check `en.js` has the key
- Check `zh.js` has the key

**Step 3: Test language switching**
- Switch to Japanese -> All text displays
- Switch to English -> All text displays
- Switch to Chinese -> All text displays

### Prevention Checklist

- [✓] Extract all keys from HTML before starting
- [✓] Add missing keys to ALL 3 files (not just one)
- [✓] Use same structure in all 3 files
- [✓] Test language switching for all 3 languages

---

## Rule 3: CSS File Placement Decision

### The Ownership Rule

Every CSS style belongs to exactly ONE file based on **component ownership**.

### Decision Table

| Component Type | Correct File | Location | Reason |
|----------------|--------------|----------|--------|
| |-- Header -> header.css
| |-- Button -> button.css
| |-- Footer -> footer.css
| |-- Form -> form.css
| Home page content | `home.css` | `pages/home/` | Screen-specific only |
| Bulletin board list | `bulletin-board.css` | `pages/bulletin-board/` | Screen-specific only |

### Common CSS (css/common/)

**Place styles here if:**
- [✓] Used in multiple screens
- [✓] Part of header, footer, or navigation
- [✓] Reusable component (buttons, forms, cards)
- [✓] Layout, typography, or base styles

**Examples:**
- Header components
- Footer components
- Button styles
- Form elements
- Typography rules
- Color variables
- Reset styles

### Screen-Specific CSS (pages/[screen]/)

**Place styles here if:**
- [✓] Used ONLY in this screen
- [✓] Not reused in other screens
- [✓] Content-specific layout
- [✓] Unique to this feature

**Examples:**
- Home page dashboard layout
- Bulletin board card grid
- Facility booking calendar
- Survey question layout

### Wrong Placement Causes Problems

**Problem 1: Duplicate Styles**
```css
/* header.css */
.welcome-header { ... }

/* home.css */
.welcome-header { ... } /*  Duplicate! */

```

**Problem 2: Maintenance Difficulty**
- Change header style  -> Must edit multiple files

- Easy to miss updates
- Inconsistent behavior

**Problem 3: Performance**
- Loading unnecessary CSS on every page
- Larger file sizes

### Decision Flowchart

**Question:** Is this component used in multiple screens?

**If YES:**
- Place in Common CSS (css/common/)
- Determine component type:
  - Header related -> header.css
  - Footer related -> footer.css
  - Button component -> button.css
  - Form component -> form.css
  - Other components -> component-name.css

**If NO:**
- Place in Screen-specific CSS (pages/[screen]/)
- File location: pages/[screen]/[screen].css

### Quick Test

Ask yourself:
1. **"Will other screens need this style?"**
   - YES -> Common CSS
   - NO -> Screen-specific CSS

2. **"Is this part of header/footer/button?"**
   - YES -> Respective component CSS
   - NO -> Check question 1

### Prevention Checklist

Before placing CSS:

- [✓] Ask "Is this used in multiple screens?"
- [✓] Check existing common CSS files first
- [] If header/footer/button related -> common CSS

- [] If screen content only -> screen-specific CSS

- [✓] When in doubt, ask for clarification

---

## Rule 4: Translation File Organization - Screen-based Split

### The Screen-based Rule

**CRITICAL: Translation files MUST be organized per screen, not globally.**

Each screen has its own set of translation files co-located with the screen files.

### Correct File Structure

```
pages/home/
 home.html

 home.css

 home.js

 home.ja.js  Home screen Japanese translations

 home.en.js  Home screen English translations

 home.zh.js  Home screen Chinese translations

pages/board/
 board.html

 board.css

 board.js

 board.ja.js  Board screen Japanese translations

 board.en.js  Board screen English translations

 board.zh.js  Board screen Chinese translations

js/i18n/langs/
 common.ja.js  Common translations ONLY (header, footer, buttons)

 common.en.js

 common.zh.js

```

### Wrong Structure (Do NOT Use)

```
 WRONG - All screens in single file:

js/i18n/langs/
 ja.js  ALL screens' Japanese (home + board + booking + ...)

 en.js  ALL screens' English (home + board + booking + ...)

 zh.js  ALL screens' Chinese (home + board + booking + ...)

```

### Why This Matters

**Scalability Problem:**
```
24 screens ” 20 keys per screen = 480 keys in single file
480 keys ” 3 lines per key = 1,440 lines
```
** ™ Violates 300-line rule** (from Development Guidelines)

**Independence:** Each screen is self-contained - easy to add, modify, or delete

**Maintainability:** Finding translations is trivial - just look in the screen's directory

**Parallel Development:** No merge conflicts when multiple developers work on different screens

**Performance:** Only load translations needed for current screen

### Translation Categories

#### Common Translations (js/i18n/langs/common.ja.js)

**Include ONLY:**
- Header elements
- Footer navigation labels
- Common button labels
- Shared error messages

**Example:**
```javascript
// common.ja.js
window.I18nData = window.I18nData || { translations: {} };
window.I18nData.translations.ja = {
// Footer navigation (short form)
'home': ' ',

'notice': ' ',

'board': '',

'booking': '',

'mypage': '',

'logout': '',

// Common buttons
'common.save': '',

'common.cancel': '""',

'common.confirm': '',

};
```

#### Screen-specific Translations (pages/[screen]/[screen].ja.js)

**Include ONLY:**
- Content area text
- Screen-specific buttons
- Screen-specific messages
- Screen-specific labels

**Example:**
```javascript
// pages/board/board.ja.js
window.I18nData = window.I18nData || { translations: {} };
window.I18nData.translations.ja = window.I18nData.translations.ja || {};

Object.assign(window.I18nData.translations.ja, {
'board.title': '',

'board.post': ' ',

'board.description': '"',

'board.category.all': '',

// ... other board-specific keys
});
```

### HTML Loading Order

**Correct order in HTML:**
```html
<body>
<!-- 1. Common translations (header, footer) -->
<script src="../../js/i18n/langs/common.ja.js"></script>
<script src="../../js/i18n/langs/common.en.js"></script>
<script src="../../js/i18n/langs/common.zh.js"></script>

<!-- 2. Screen-specific translations (content area) -->
<script src="board.ja.js"></script>
<script src="board.en.js"></script>
<script src="board.zh.js"></script>

<!-- 3. Common features (REQUIRED: translator, language-switcher, footer-navigation) -->
<script src="../../js/features/translator.js"></script>
<script src="../../js/features/language-switcher.js"></script>
<script src="../../js/features/footer-navigation.js"></script>

<!-- 4. Screen-specific logic -->
<script src="board.js"></script>
</body>
```

**CRITICAL: Load Order Rules**
- Translation data (steps 1-2) MUST load BEFORE feature modules (step 3)
- footer-navigation.js is REQUIRED for all screens (not optional)
- Incorrect order causes translation failures requiring cache clear (Ctrl+Shift+R)

### File Size Guidelines

**Maximum file sizes:**
- Common translation file: ~100 lines (~10 keys)
- Screen translation file: ~60 lines (~20 keys)
- Total per screen: 180 lines (well under 300-line limit)

### Migration from Old Structure

If you find old structure with consolidated `ja.js`, `en.js`, `zh.js`:

1. Extract common keys ™ `common.ja.js`, `common.en.js`, `common.zh.js`
2. Extract screen keys ™ `[screen].ja.js`, `[screen].en.js`, `[screen].zh.js`
3. Delete old consolidated files
4. Update all HTML files to load new structure

### Prevention Checklist

Before adding translation keys:

- [✓] Is this key used in header/footer? ™ Add to `common.[lang].js`
- [✓] Is this key used in content area? ™ Add to `[screen].[lang].js`
- [✓] Added to ALL 3 language files? (ja, en, zh)
- [✓] Files under 300 lines?
- [✓] HTML loads common translations first?

---

## Summary

### Four Critical Rules

1. **CSS Variables**  Define before use, check `variables.css`

1. **CSS Variables** ™ Define before use, check `variables.css`
2. **Translation Keys** ™ Always 3-language set (ja/en/zh)
3. **CSS Placement** ™ Common vs Screen-specific decision
4. **Translation Files** ™ Screen-based split, not global consolidation

### Impact

Following these rules prevents:
-  Silent layout failures

-  Raw key display in UI

-  Style duplication and maintenance issues

-  Inconsistent behavior across screens

-  Massive translation files (violating 300-line rule)

-  Merge conflicts in translation files

### Next Steps

When generating code:
1. Review this file FIRST
2. Apply all four rules
3. Use checklists for verification
4. Test thoroughly

---

**Last Updated:** 2025/10/25
**Version:** 2.1 (Fixed translation data structure: window.I18nData.translations)
**Related Files:** troubleshooting.md, checklist.md
