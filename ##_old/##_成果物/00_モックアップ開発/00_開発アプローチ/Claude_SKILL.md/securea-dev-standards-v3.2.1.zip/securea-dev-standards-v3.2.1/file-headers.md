# File Header Comments

## Required for ALL Files

Every HTML/CSS/JS file must have a header comment.

---

## HTML Files

```html
<!--
  File: /pages/[screen]/[screen].html
  Screen: [Screen Name]
  
  Usage:
  1. Copy this file to new screen directory
  2. Rename to [screen].html
  3. Replace [template] with actual screen ID
  4. Edit content area (<main>) only
  5. Keep header/footer unchanged
-->
```

---

## CSS Files

```css
/**
 * File: /pages/[screen]/[screen].css
 * Purpose: [Screen Name] screen-specific styles
 * 
 * Features:
 * - Feature 1
 * - Feature 2
 */
```

---

## JavaScript Files

```javascript
/**
 * File: /pages/[screen]/[screen].js
 * Purpose: [Screen Name] screen-specific logic
 * 
 * Dependencies:
 * - window.LanguageManager
 * - window.I18nData
 */
```

---

## Purpose

- Instantly identify file location and role
- Prevent confusion in multi-person development
- Clarify context for AI-assisted development

---

## Rules

1. Always place at file top
2. Use appropriate comment syntax for file type
3. Include file path from project root
4. Briefly describe purpose
5. List dependencies if any
