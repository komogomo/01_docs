# Page Structure

## 3-Layer Screen Structure

All screens (except index.html) follow this structure:

```html
<header class="page-header">
  <!-- Common area - DO NOT EDIT -->
  <!-- App name, notifications, language switcher, title -->
</header>

<main class="page-content">
  <!-- Screen-specific content - EDIT THIS ONLY -->
</main>

<footer class="page-footer">
  <!-- Common area - DO NOT EDIT -->
  <!-- Navigation buttons (5) + logout button (right) -->
</footer>
```

---

## 1. Header Area

### Structure
```html
<header class="page-header">
  <div class="page-header__container">
    <h1 class="header-title" data-i18n="[screen].header.title">
      Screen Title
    </h1>
    <div class="language-switcher">
      <button class="lang-btn" data-lang="ja">JA</button>
      <button class="lang-btn" data-lang="en">EN</button>
      <button class="lang-btn" data-lang="zh">ZH</button>
    </div>
  </div>
</header>
```

### Rules
- ❌ DO NOT modify header structure
- ❌ DO NOT add/remove elements
- ✅ Only change title translation key

---

## 2. Content Area

### Structure
```html
<main class="page-content">
  <div class="content-container">
    <!-- YOUR CONTENT HERE -->
  </div>
</main>
```

### Rules
- ✅ Modify this area freely
- ✅ Add any screen-specific content
- ✅ Use custom classes and IDs
- ❌ Do not modify page-content wrapper

---

## 3. Footer Area

### Structure
```html
<footer class="page-footer">
  <div class="page-footer__container">
    <a href="../home/home.html" class="footer-nav-btn" data-page="home">
      <span class="footer-nav-icon">🏠</span>
      <span class="footer-nav-label" data-i18n="footer.nav.home">Home</span>
    </a>
    <!-- 4 more nav buttons -->
    <a href="../../index.html" class="footer-nav-btn footer-nav-btn--logout">
      <span class="footer-nav-icon">🚪</span>
      <span class="footer-nav-label" data-i18n="logout">Logout</span>
    </a>
  </div>
</footer>
```

### Rules
- ❌ DO NOT modify footer structure
- ❌ DO NOT add/remove buttons
- ✅ Logout button always on right edge

---

## index.html Exception

- Location: Project root
- Structure: Custom (not 3-layer)
- CSS/JS: Inline OK
- Changes: Generally prohibited
