# Troubleshooting

## Top 3 Issues and Prevention

---

## Issue 1: Translation Not Working

### Symptoms
- Text shows translation keys (e.g. "home.title")
- Text remains in Japanese even after language switch
- Console errors about i18n

### Root Causes
1. **Missing translation key** in common.[lang].js or [screen].[lang].js
2. **Wrong data-i18n attribute** value
3. **JS load order** incorrect
4. **Translation function** not initialized
5. **Translation files in wrong location**

### Prevention
✅ Define keys in ALL language files (ja/en/zh)
✅ Common keys → common.[lang].js (header, footer, buttons)
✅ Screen keys → [screen].[lang].js (content area)
✅ Use consistent key format: [screen].[element] or [screen].[section].[element]
✅ Load common translations before screen translations
✅ Initialize language manager properly

### Quick Fix
1. Check browser console for errors
2. Verify translation key location:
   - Header/footer/button text → Check `js/i18n/langs/common.[lang].js`
   - Content area text → Check `pages/[screen]/[screen].[lang].js`
3. Verify key exists in ALL 3 language files (ja/en/zh)
4. Confirm data-i18n value matches key
5. Verify JS load order (common translations → features → screen translations)

### Debugging Steps
```
1. Is the text in header/footer?
   YES → Check js/i18n/langs/common.ja.js, common.en.js, common.zh.js
   NO → Check pages/[screen]/[screen].ja.js, [screen].en.js, [screen].zh.js

2. Does the key exist in the file?
   YES → Check data-i18n attribute value
   NO → Add key to ALL 3 language files

3. Are files loaded in correct order?
   Check: common translations → features → screen translations
```

---

## Issue 2: CSS Not Applied

### Symptoms
- Styles don't appear
- Wrong colors/spacing
- Layout broken

### Root Causes
1. **CSS load order** wrong
2. **Specificity conflict**
3. **`!important` usage** (prohibited!)
4. **Class name** typo

### Prevention
✅ Follow strict CSS load order (Tailwind → variables → reset → base → common → screen)
✅ Use BEM notation correctly
✅ NEVER use `!important`
✅ Double-check class names

### Quick Fix
1. Check CSS load order in HTML
2. Check browser DevTools for applied styles
3. Verify class names match CSS definitions
4. Remove any `!important` declarations

---

## Issue 3: Footer Active State Wrong

### Symptoms
- Wrong button highlighted in footer
- Multiple buttons highlighted
- No button highlighted

### Root Causes
1. **data-page attribute** missing or wrong
2. **footer-navigation.js** not loaded
3. **Current page path** doesn't match logic

### Prevention
✅ Set correct data-page on all footer buttons
✅ Load footer-navigation.js
✅ Use consistent file paths

### Quick Fix
1. Check data-page attribute on footer buttons
2. Verify footer-navigation.js is loaded
3. Check browser console for errors
4. Confirm current page path matches expected pattern

---

## General Debugging Tips

### Browser DevTools
1. **Console** - Check for errors
2. **Elements** - Inspect HTML/CSS
3. **Network** - Verify file loading
4. **Sources** - Debug JavaScript

### Common Checks
- ✅ Files loaded in correct order?
- ✅ No 404 errors in Network tab?
- ✅ Translation keys defined in correct files?
- ✅ Class names spelled correctly?
- ✅ Global variables initialized?

### Translation-Specific Checks
- ✅ Common translations loaded before features?
- ✅ Screen translations loaded after features?
- ✅ Translation files under 300 lines?
- ✅ Keys in ALL 3 language files?

### When Stuck
1. Check existing working screens
2. Compare with template (page-template.html)
3. Reference skill documentation
4. Ask explicitly about specific issue
5. Verify translation file structure (common vs screen-specific)
