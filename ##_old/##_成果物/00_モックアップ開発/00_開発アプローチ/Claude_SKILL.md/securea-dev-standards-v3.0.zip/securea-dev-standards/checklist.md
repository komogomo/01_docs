# Checklist and Prohibited Items

## Post-Creation Verification Checklist

### Naming
- □ File name in kebab-case? (e.g. language-switcher.js)
- □ Global variables as window.Capitalized? (e.g. window.LanguageSwitcher)
- □ CSS classes in BEM notation? (e.g. .footer-nav__button--active)

### Structure
- □ HTML follows 3-layer structure (header, content, footer)?
- □ File header comment present?
- □ CSS load order correct? (variables → reset → base → common → pages)
- □ JavaScript load order correct? (i18n data → features → screen-specific)

### Placement
- □ Common buttons only in common/button.css?
- □ Screen-specific styles in pages/[screen].css?
- □ Independent features in features/?
- □ Screen-specific logic in pages/?

### Translation
- □ data-i18n attributes set correctly?
- □ Translation keys defined in all language files? (ja/en/zh)
- □ Translation key format unified? ([screen-id].[section].[element])

### Operation Check
- □ Language switching works?
- □ Translations applied correctly?
- □ Styles applied correctly?
- □ Footer nav active state correct?
- □ No browser console errors?

---

## Prohibited Items

### Absolutely Forbidden

#### CSS
- ❌ **Using `!important`**
  - Causes specificity issues
  - Creates unmaintainable code
  
- ❌ **Changing CSS load order**
  - Styles won't apply correctly
  - Causes unexpected display issues

#### File Naming
- ❌ **Underscore-separated file names**
  - Correct: language-switcher.js
  - Wrong: language_switcher.js

- ❌ **Capitalized file names**
  - Correct: home.html
  - Wrong: Home.html

#### JavaScript
- ❌ **Lowercase global variables**
  - Correct: window.LanguageSwitcher
  - Wrong: window.languageSwitcher

- ❌ **Global variables without window**
  - Correct: window.Translator
  - Wrong: let Translator (global scope)

#### File Placement
- ❌ **Common buttons in pages/**
  - Header/footer buttons only in common/button.css

- ❌ **Screen-specific styles in common/**
  - Single-screen styles go in pages/

#### HTML Structure
- ❌ **Custom edits to header/footer areas**
  - Common areas are off-limits
  - Edit content area (main) only

---

## Discouraged Practices

### Better to Avoid

#### Excessive Commonization
```
✗ Place single-use styles in common/
✓ Consider commonization when used 2+ times
```

#### Inline Styles
```html
✗ <div style="color: red;">NG</div>
✓ <div class="error-message">OK</div>
```

#### Heavy ID Selector Usage
```css
✗ #header { ... }
✓ .page-header { ... }
```

**Reason:**
- IDs have too high specificity
- Low reusability
- Poor compatibility with BEM

#### Deep Nesting
```css
✗ .page-header .language-switcher .lang-btn.active { }
✓ .lang-btn--active { }
```

**Reason:**
- Specificity gets too high
- Difficult to maintain
- Unnecessary with BEM

---

## Code Review Points

### When Reviewing Others' Code
1. Check all checklist items
2. Verify no prohibited items
3. Confirm naming conventions followed
4. Verify consistency with existing patterns

### When Reviewing Own Code
1. Test actual operation in browser
2. Check display in multiple languages
3. Check for console errors
4. Check responsive design (if needed)
