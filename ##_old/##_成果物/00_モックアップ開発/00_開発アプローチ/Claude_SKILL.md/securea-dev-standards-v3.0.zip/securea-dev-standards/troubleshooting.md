# Troubleshooting

## Top 3 Issues and Prevention

---

## Issue 1: Translation Not Working

### Symptoms
- Text shows translation keys (e.g. "home.title")
- Text remains in Japanese even after language switch
- Console errors about i18n

### Root Causes
1. **Missing translation key** in ja.js/en.js/zh.js
2. **Wrong data-i18n attribute** value
3. **JS load order** incorrect
4. **Translation function** not initialized

### Prevention
✅ Define keys in ALL language files (ja/en/zh)
✅ Use consistent key format: [screen].[section].[element]
✅ Load i18n files before features
✅ Initialize language manager properly

### Quick Fix
1. Check browser console for errors
2. Verify translation key exists in all lang files
3. Confirm data-i18n value matches key
4. Verify JS load order

---

## Issue 2: CSS Not Applied

### Symptoms
- Styles don't appear
- Wrong colors/spacing
- Layout broken

### Root Causes
1. **CSS load order** wrong
2. **Specificity conflict**
3. **`!important` usage** (prohibited!)
4. **Class name** typo

### Prevention
✅ Follow strict CSS load order (Tailwind → variables → reset → base → common → screen)
✅ Use BEM notation correctly
✅ NEVER use `!important`
✅ Double-check class names

### Quick Fix
1. Check CSS load order in HTML
2. Check browser DevTools for applied styles
3. Verify class names match CSS definitions
4. Remove any `!important` declarations

---

## Issue 3: Footer Active State Wrong

### Symptoms
- Wrong button highlighted in footer
- Multiple buttons highlighted
- No button highlighted

### Root Causes
1. **data-page attribute** missing or wrong
2. **footer-navigation.js** not loaded
3. **Current page path** doesn't match logic

### Prevention
✅ Set correct data-page on all footer buttons
✅ Load footer-navigation.js
✅ Use consistent file paths

### Quick Fix
1. Check data-page attribute on footer buttons
2. Verify footer-navigation.js is loaded
3. Check browser console for errors
4. Confirm current page path matches expected pattern

---

## General Debugging Tips

### Browser DevTools
1. **Console** - Check for errors
2. **Elements** - Inspect HTML/CSS
3. **Network** - Verify file loading
4. **Sources** - Debug JavaScript

### Common Checks
- ✅ Files loaded in correct order?
- ✅ No 404 errors in Network tab?
- ✅ Translation keys defined?
- ✅ Class names spelled correctly?
- ✅ Global variables initialized?

### When Stuck
1. Check existing working screens
2. Compare with template
3. Reference skill documentation
4. Ask explicitly about specific issue
