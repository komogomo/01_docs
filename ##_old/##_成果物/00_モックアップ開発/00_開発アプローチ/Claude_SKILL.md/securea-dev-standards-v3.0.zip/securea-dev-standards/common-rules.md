# Common Rules

## Global Variables

### Rule
**All global variables must be attached to window object and capitalized**

```javascript
✓ window.LanguageSwitcher
✓ window.Translator
✓ window.I18nData

✗ languageSwitcher
✗ window.translator
```

### Reason
- Prevent global scope pollution
- Avoid name conflicts with other libraries
- Clearly indicate global nature

---

## Common Buttons

### Rule
**All common buttons (header, footer) are defined ONLY in common/button.css**

### Examples
- Language switcher buttons
- Footer navigation buttons
- Logout button

### Prohibited
❌ Defining common buttons in pages/[screen].css
❌ Duplicating button styles

### Correct Approach
✓ Define in common/button.css once
✓ Use same classes across all screens
✓ Customize via modifiers only

---

## Translation Keys

### Format
```
[screen-id].[section].[element]
```

### Examples
```javascript
'home.header.title': 'Home',
'board.content.new': 'New Post',
'booking.button.reserve': 'Reserve',
```

### Rules
- All keys in all language files (ja/en/zh)
- Use descriptive names
- Follow hierarchical structure

---

## CSS Load Order

### STRICT ORDER (Never change!)
```html
1. Tailwind CDN
2. variables.css
3. reset.css
4. base.css
5. common/*.css
6. [screen].css
```

### Reason
- Ensures correct cascade
- Prevents style conflicts
- Maintains predictable behavior
