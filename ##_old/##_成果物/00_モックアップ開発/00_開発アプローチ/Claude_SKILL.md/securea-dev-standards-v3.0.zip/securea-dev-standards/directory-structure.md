# Directory Structure

## Project Root

```
project-root/
├── index.html                    # Login screen (exception)
├── templates/
│   └── page-template.html        # Standard 3-layer template
├── css/
│   ├── variables.css
│   ├── reset.css
│   ├── base.css
│   └── common/
│       ├── button.css
│       ├── header.css
│       ├── footer.css
│       └── layout.css
├── js/
│   ├── i18n/
│   │   └── langs/
│   │       ├── ja.js
│   │       ├── en.js
│   │       └── zh.js
│   └── features/
│       ├── language-switcher.js
│       ├── translator.js
│       └── footer-navigation.js
└── pages/
    ├── home/
    │   ├── home.html
    │   ├── home.css
    │   └── home.js
    ├── board/
    │   ├── board.html
    │   ├── board.css
    │   ├── board.js
    │   ├── board-editor.css        # Feature-specific
    │   └── board-editor.js         # Feature-specific
    └── booking/
        ├── booking.html
        ├── booking.css
        └── booking.js
```

---

## Key Principles

### 1. Screen-Specific Files Together
**All files for one screen in same directory**
- HTML, CSS, JS in pages/[screen]/
- Easy to find, modify, delete

### 2. Common Files Separated
- CSS common components → css/common/
- JS independent features → js/features/
- Translation data → js/i18n/langs/

### 3. Feature-Based Splitting
When files exceed 300 lines:
```
pages/screen/
├── screen.html
├── screen.css
├── screen.js
├── screen-feature1.css
└── screen-feature2.js
```

---

## File Placement Rules

### HTML Files
- **Location:** `pages/[screen]/[screen].html`
- **Naming:** kebab-case, all lowercase

### CSS Files
**Screen-specific:** `pages/[screen]/[screen].css`
**Common:** `css/common/[component].css`

### JavaScript Files
**Screen-specific:** `pages/[screen]/[screen].js`
**Common features:** `js/features/[feature].js`

### Translation Data
**Location:** `js/i18n/langs/[lang].js`
**Files:** ja.js, en.js, zh.js
**Content:** All screens' translations consolidated
