# New Page Creation Guide

## Step-by-Step Procedure

---

## Step 1: Create Directory

```bash
mkdir pages/[screen-name]/
```

Example:
```bash
mkdir pages/home/
```

---

## Step 2: Copy Template

```bash
cp templates/page-template.html pages/[screen-name]/[screen-name].html
```

Example:
```bash
cp templates/page-template.html pages/home/home.html
```

---

## Step 3: Create CSS/JS Files

```bash
touch pages/[screen-name]/[screen-name].css
touch pages/[screen-name]/[screen-name].js
```

Example:
```bash
touch pages/home/home.css
touch pages/home/home.js
```

---

## Step 4: Edit HTML File

### 4.1 Update File Header
```html
<!--
  File: /pages/home/home.html
  Screen: Home Screen
-->
```

### 4.2 Fix CSS Load Path
```html
<!-- Screen-specific CSS (same directory) -->
<link rel="stylesheet" href="home.css">
```

### 4.3 Fix JS Load Path
```html
<!-- Screen-specific JavaScript (same directory) -->
<script src="home.js"></script>
```

### 4.4 Edit Content Area
Modify only `<main>` section

---

## Step 5: Add Translation Keys

Add to `js/i18n/langs/ja.js`, `en.js`, `zh.js`:

```javascript
// ja.js
'home.header.title': 'ホーム',
'home.content.welcome': 'ようこそ',
```

```javascript
// en.js
'home.header.title': 'Home',
'home.content.welcome': 'Welcome',
```

```javascript
// zh.js
'home.header.title': '主页',
'home.content.welcome': '欢迎',
```

---

## Step 6: Test Locally

### Check List
- □ Load screen in browser
- □ Switch languages (JA/EN/ZH)
- □ Check translations work
- □ Check styles applied
- □ Check footer nav active state
- □ Check console for errors

---

## Quick Checklist

New screen creation checklist:

- □ Created `pages/[screen]/` directory
- □ Copied template
- □ Added file header comment
- □ Created CSS/JS in **same directory**
- □ Fixed CSS/JS load paths (same directory)
- □ Added Tailwind CDN
- □ Added logout button (footer right)
- □ Added translation keys (ja/en/zh)
- □ Tested locally
- □ Language switching works
- □ Footer nav works
- □ Logout button works

---

## Common Mistakes

### 1. CSS/JS in Wrong Location
❌ css/pages/home.css
✓ pages/home/home.css

### 2. Wrong Load Path
❌ `<link href="../../css/pages/home.css">`
✓ `<link href="home.css">`

### 3. Missing Translation Keys
Must add to ALL three language files (ja/en/zh)

### 4. Editing Header/Footer
Only edit `<main>` content area
