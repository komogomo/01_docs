# ディレクトリ構造

## プロジェクト全体の構造

```
securea-city-static/
├── index.html                    # ログイン画面
├── templates/
│   └── page-template.html        # 画面テンプレート
├── css/
│   ├── variables.css             # CSS変数
│   ├── reset.css                 # リセットCSS
│   ├── base.css                  # 基本スタイル
│   └── common/                   # 共通コンポーネントのみ
│       ├── button.css            # ヘッダー・フッターのボタンのみ
│       ├── header.css            # 共通ヘッダー
│       ├── footer.css            # 共通フッター
│       └── layout.css            # レイアウト
├── js/
│   ├── features/                 # 独立機能（UI依存）
│   │   ├── language-switcher.js
│   │   ├── translator.js
│   │   └── footer-navigation.js
│   ├── i18n/                     # 多言語対応
│   │   └── langs/
│   │       ├── ja.js
│   │       ├── en.js
│   │       └── zh.js
│   └── common/                   # 共通ユーティリティ（DOM非依存）
│       └── utils.js
└── pages/
    └── [画面]/
        ├── [画面].html           # HTML
        ├── [画面].css            # 画面固有CSS
        └── [画面].js             # 画面固有JS
```

---

## ディレクトリの役割

### css/
- **variables.css** - CSS変数（色、フォント、サイズ等）
- **reset.css** - ブラウザデフォルトスタイルのリセット
- **base.css** - 基本的なHTML要素のスタイル
- **common/** - 複数画面で共有するコンポーネント**のみ**

**重要:** 画面固有CSSは `pages/[画面]/` に配置

### js/
- **features/** - UI操作と密接に関連する独立機能
  - 言語切替、翻訳、フッターナビゲーション等
- **i18n/** - 多言語対応関連
  - 言語ファイル（ja.js, en.js, zh.js）
- **common/** - DOM操作に依存しない汎用ユーティリティ

**重要:** 画面固有JSは `pages/[画面]/` に配置

### pages/
- 各画面のHTML/CSS/JSファイルを**同一ディレクトリに**格納
- 画面名でディレクトリを作成し、その中に3ファイルを配置

---

## ファイル配置の原則

### 画面固有ファイル（HTML/CSS/JS）
```
pages/[画面名]/
├── [画面名].html
├── [画面名].css
└── [画面名].js
```

**例:**
```
pages/home/
├── home.html
├── home.css
└── home.js
```

### 共通CSSファイル
```
複数画面で共有するコンポーネント → css/common/
```

### 共通JavaScriptファイル
```
UI依存の独立機能 → js/features/
汎用ユーティリティ → js/common/
```

### ログイン画面
```
index.html → プロジェクトルート
```

---

## 新旧比較

### 旧構造
```
pages/home/home.html
css/pages/home.css
js/pages/home.js
```

### 新構造
```
pages/home/
├── home.html
├── home.css
└── home.js
```

**変更理由:**
- 画面単位でのファイル管理が容易
- 修正・削除が1箇所で完結
- 保守性の向上
